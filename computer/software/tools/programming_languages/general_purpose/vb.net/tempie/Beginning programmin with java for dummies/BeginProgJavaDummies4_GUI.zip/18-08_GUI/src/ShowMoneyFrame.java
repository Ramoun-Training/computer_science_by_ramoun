public class ShowMoneyFrame {
    
    public static void main(String args[]) {
        new MoneyFrame();
    }
}
